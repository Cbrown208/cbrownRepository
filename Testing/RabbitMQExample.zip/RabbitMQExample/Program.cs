﻿namespace RabbitMQExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Send.SendMessage();
            //Send.SendMessage();

            //Receive.GetMessage();
        }
    }
}
